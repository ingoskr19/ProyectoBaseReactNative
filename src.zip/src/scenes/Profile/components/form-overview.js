import React from 'react';
import { 
    View, 
    Text, 
    TextInput, 
    Switch,
    Button, 
    StyleSheet 
} from 'react-native'

const FormOverview = props => (
    <View style={styles.formWrapper}>
        <Text style={styles.formLabel}> {props.profile.name} </Text>
        <TextInput
            placeholder="Name here...."
            style={styles.formInput}
        />
        <Text style={styles.formLabel}> {props.profile.twitter} </Text>
        <TextInput
            placeholder="Twiter username here..."
            style={styles.formInput}
        />
        <Text style={styles.formLabel}> {props.profile.phone} </Text>
        <TextInput
            placeholder="Twiter username"
            style={styles.formInput}
        />
        <Text style={styles.formLabel}> {props.profile.location} </Text>
        <TextInput
            placeholder="Location username"
            style={styles.formInput}
        />
        <Text style={styles.formLabel}> Allow Share Social Data </Text>
        <Switch
            onTintColor={'#4A148C'}
            value={true}/>
        <Button
            onPress={ props.onPress}
            title={1==2 ?"Sync with Facebook":"no show nothin"}
            color={'#4A148C'}/>
    </View>
)

const styles = StyleSheet.create({ 
  formWrapper:{
    marginVertical:15,
  },
  formLabel:{
    color:'#4527A0',
  },
  formInput:{
    borderBottomWidth:1,
    borderBottomColor:'#ccc',
  }
});

export default FormOverview;